<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

session_start();

// =========================
//  Enkel konfigurering
// =========================

// Byt ut detta till ditt riktiga lösenord (samma som du loggar in med i appen)
$PASSWORD = 'byt-mig';

// Var ska data sparas?
$DATA_FILE = __DIR__ . '/data.json';

// =========================
//  Hjälpfunktioner
// =========================

function load_data(string $file): array
{
    if (!file_exists($file)) {
        return [
            'items' => [],
            'configs' => []
        ];
    }

    $raw = file_get_contents($file);
    if ($raw === false || $raw === '') {
        return [
            'items' => [],
            'configs' => []
        ];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        // Gammalt format: ren lista med prylar
        return [
            'items' => [],
            'configs' => []
        ];
    }

    // Om någon gång filen sparats som ren array med prylar
    if (array_keys($decoded) === range(0, count($decoded) - 1)) {
        return [
            'items' => $decoded,
            'configs' => []
        ];
    }

    // Nytt format: objekt med items + configs
    return [
        'items'   => isset($decoded['items']) && is_array($decoded['items'])   ? $decoded['items']   : [],
        'configs' => isset($decoded['configs']) && is_array($decoded['configs']) ? $decoded['configs'] : []
    ];
}

function save_data(string $file, array $data): bool
{
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }

    $tmp = $file . '.tmp';
    if (file_put_contents($tmp, $json) === false) {
        return false;
    }

    return rename($tmp, $file);
}

function get_id(array $item): ?string
{
    if (isset($item['id']) && is_string($item['id']) && $item['id'] !== '') {
        return $item['id'];
    }
    return null;
}

function get_updated_at(array $item): int
{
    if (!isset($item['updatedAt']) || !is_string($item['updatedAt'])) {
        return 0;
    }
    $t = strtotime($item['updatedAt']);
    if ($t === false) {
        return 0;
    }
    return $t;
}

// =========================
//  Auth-hantering
// =========================

$action = $_GET['action'] ?? null;

if ($action === 'session') {
    $loggedIn = isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
    echo json_encode(['loggedIn' => $loggedIn]);
    exit;
}

if ($action === 'login') {
    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);
    $password = is_array($payload) && isset($payload['password']) ? (string)$payload['password'] : '';

    if (hash_equals($PASSWORD, $password)) {
        $_SESSION['logged_in'] = true;
        echo json_encode(['ok' => true]);
    } else {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'wrong-password']);
    }
    exit;
}

// Alla andra requests kräver inloggning
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'not-logged-in']);
    exit;
}

// =========================
//  GET = hämta data
// =========================

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = load_data($DATA_FILE);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// =========================
//  POST = spara / merga data
// =========================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);

    if (!is_array($payload)) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid-json']);
        exit;
    }

    $clientItems = isset($payload['items']) && is_array($payload['items']) ? $payload['items'] : [];
    $clientConfigs = isset($payload['configs']) && is_array($payload['configs']) ? $payload['configs'] : [];

    $deletedItemIds = isset($payload['deletedItemIds']) && is_array($payload['deletedItemIds'])
        ? array_values(array_filter($payload['deletedItemIds'], 'is_string'))
        : [];

    $deletedConfigIds = isset($payload['deletedConfigIds']) && is_array($payload['deletedConfigIds'])
        ? array_values(array_filter($payload['deletedConfigIds'], 'is_string'))
        : [];

    // Lås filen under läs/skriv
    $fp = fopen($DATA_FILE, 'c+');
    if ($fp === false) {
        http_response_code(500);
        echo json_encode(['error' => 'cannot-open-data-file']);
        exit;
    }

    flock($fp, LOCK_EX);

    // Läs aktuell data
    $serverData = load_data($DATA_FILE);
    $serverItems = $serverData['items'];
    $serverConfigs = $serverData['configs'];

    // --- Merging för items ---

    $mergedItemsById = [];

    // Börja med serverns version
    foreach ($serverItems as $item) {
        $id = get_id($item);
        if ($id === null) {
            continue;
        }
        $mergedItemsById[$id] = $item;
    }

    // Lägg på klientens version med "senast uppdaterad vinner"
    foreach ($clientItems as $item) {
        $id = get_id($item);
        if ($id === null) {
            continue;
        }

        if (!isset($mergedItemsById[$id])) {
            // Ny på klienten
            $mergedItemsById[$id] = $item;
        } else {
            $serverItem = $mergedItemsById[$id];
            $serverTime = get_updated_at($serverItem);
            $clientTime = get_updated_at($item);

            if ($clientTime >= $serverTime) {
                $mergedItemsById[$id] = $item;
            }
        }
    }

    // Ta bort allt som uttryckligen markerats som raderat
    foreach ($deletedItemIds as $delId) {
        if (isset($mergedItemsById[$delId])) {
            unset($mergedItemsById[$delId]);
        }
    }

    $mergedItems = array_values($mergedItemsById);

    // --- Merging för configs ---

    $mergedConfigsById = [];

    foreach ($serverConfigs as $cfg) {
        $id = get_id($cfg);
        if ($id === null) {
            continue;
        }
        $mergedConfigsById[$id] = $cfg;
    }

    foreach ($clientConfigs as $cfg) {
        $id = get_id($cfg);
        if ($id === null) {
            continue;
        }

        if (!isset($mergedConfigsById[$id])) {
            $mergedConfigsById[$id] = $cfg;
        } else {
            $serverCfg = $mergedConfigsById[$id];
            $serverTime = get_updated_at($serverCfg);
            $clientTime = get_updated_at($cfg);

            if ($clientTime >= $serverTime) {
                $mergedConfigsById[$id] = $cfg;
            }
        }
    }

    foreach ($deletedConfigIds as $delId) {
        if (isset($mergedConfigsById[$delId])) {
            unset($mergedConfigsById[$delId]);
        }
    }

    $mergedConfigs = array_values($mergedConfigsById);

    // Spara tillbaka
    $finalData = [
        'items'   => $mergedItems,
        'configs' => $mergedConfigs
    ];

    rewind($fp);
    ftruncate($fp, 0);
    $ok = save_data($DATA_FILE, $finalData);

    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    if (!$ok) {
        http_response_code(500);
        echo json_encode(['error' => 'failed-to-save']);
        exit;
    }

    echo json_encode(['ok' => true]);
    exit;
}

// Om vi hamnar här är det en metod vi inte stödjer
http_response_code(405);
echo json_encode(['error' => 'method-not-allowed']);