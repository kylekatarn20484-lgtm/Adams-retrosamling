<?php
// upload.php – enkel och robust filuppladdning för bilder

// För felsökning: sätt till 1 om du vill se PHP-fel direkt i svaret
ini_set('display_errors', 0);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

// Katalog där bilderna ska hamna
$uploadDir = __DIR__ . '/uploads';
$publicBase = 'uploads/'; // detta är vad frontend sparar som imageDataUrl

if (!is_dir($uploadDir)) {
    if (!mkdir($uploadDir, 0775, true)) {
        http_response_code(500);
        echo json_encode([
            'ok'    => false,
            'error' => 'Kunde inte skapa upload-katalog.'
        ]);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'ok'    => false,
        'error' => 'Endast POST-stöds för uppladdning.'
    ]);
    exit;
}

if (!isset($_FILES['images'])) {
    http_response_code(400);
    echo json_encode([
        'ok'    => false,
        'error' => 'Inga filer mottogs (fältet images saknas).'
    ]);
    exit;
}

// $_FILES['images'] är ett fält med flera filer (images[])
$files = $_FILES['images'];
$count = is_array($files['name']) ? count($files['name']) : 0;

$allowedExt = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
$savedFiles = [];

for ($i = 0; $i < $count; $i++) {
    $error = $files['error'][$i];

    if ($error !== UPLOAD_ERR_OK) {
        // Hoppa över denna fil, men fortsätt med ev. andra
        continue;
    }

    $tmpName = $files['tmp_name'][$i];
    $origName = $files['name'][$i];
    $size     = $files['size'][$i];

    // Kolla filändelse
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true)) {
        // Hoppa över icke-bildfiler
        continue;
    }

    // Extra failsafe: släng extremt stora filer (browsern ska ha komprimerat först)
    // t.ex. max 6 MB
    if ($size > 6 * 1024 * 1024) {
        continue;
    }

    // Skapa unikt filnamn
    $newName = uniqid('img_', true) . '.' . $ext;
    $destPath = $uploadDir . '/' . $newName;

    if (!move_uploaded_file($tmpName, $destPath)) {
        // Kunde inte flytta filen, hoppa över
        continue;
    }

    // Spara den publika sökvägen (relativ)
    $savedFiles[] = $publicBase . $newName;
}

if (empty($savedFiles)) {
    http_response_code(400);
    echo json_encode([
        'ok'    => false,
        'error' => 'Inga filer sparades (fel typ, för stora eller flyttproblem).'
    ]);
    exit;
}

// Allt gick bra – svara i ett format som frontendens uploadImages förstår
echo json_encode([
    'ok'    => true,
    'files' => $savedFiles
]);